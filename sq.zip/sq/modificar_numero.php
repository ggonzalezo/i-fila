<?php
$numero = $_GET['numero'];
$local = $_GET['local'];
$segundos = time();

echo $numero." ".$local." ".$segundos."<br>";

	include("acceso_db.php");
	
		$sql_turnos = mysql_query("SELECT * FROM turnos where id_local =  $local order by id desc LIMIT 1");
		$anterior = mysql_fetch_array($sql_turnos);
		
		
		if($anterior['turno']==$numero){		
		}else{
		$intervalo_actual = round(($segundos-$anterior['segundos'])/($numero-$anterior['turno']));
		$sql_consulta = mysql_query("INSERT INTO  `turnos` (  `turno` , `id_local`,`segundos`,`intervalo` ) VALUES ($numero,  $local, $segundos, $intervalo_actual)");
		$row_clientes = mysql_fetch_array($sql_consulta);
		}

		$intervalo = array();
		$sql_turnos = mysql_query("SELECT * FROM turnos where id_local =  $local order by id desc LIMIT 3");
		while($row_turnos = mysql_fetch_array($sql_turnos)){
		echo $row_turnos['turno']."<br>";
		$intervalo[]=$row_turnos['intervalo'];
		}
		$prom_intervalo = round(($intervalo[0]+$intervalo[1]+$intervalo[2])/3);
		
		echo "intervalo promedio: ".$prom_intervalo."<br>";
		echo "intervalo: ".$intervalo_actual."<br>";
		
		
?>
