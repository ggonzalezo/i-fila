<?php
// se carga información de  intervalo estadistico y numero real (actualizado por el usaurio)
$id_muni = 1;

$dbc = @mysqli_connect('localhost', 'armatuli_rc', 'rc2014rc', 'armatuli_rc');
	@mysqli_select_db($dbc, "armatuli_rc");
	
	
		$consulta1 = "SELECT * FROM intervalos where id_muni =  $id_muni order by id asc LIMIT 1";
		$resultado1 = Mysqli_query($dbc, $consulta1);
		$fila1 = mysqli_fetch_assoc($resultado1);
		
		$consulta2 = "SELECT * FROM turnos where id_muni =  $id_muni order by id desc LIMIT 15";	
		$resultado2 = Mysqli_query($dbc, $consulta2);
		
		$i = 0;
		while($fila2 = mysqli_fetch_assoc($resultado2)){

			$date0 = $fila2['hora'];
			$datehora = date('H A', strtotime($date0));
			$dateminuto = date('i A', strtotime($date0));
			$tiempo[$i] = $dateminuto + $datehora*60;
			$turno[$i] = $fila2['turno'];
			echo "turno: ".$turno[$i]." hora: ".$tiempo[$i]."<br>";
			$i++;
			
		}
		$cantidad = count($tiempo)-1;
		$tiempototal = $tiempo['0']-$tiempo[$cantidad];
		$turnostotal = $turno['0']-$turno[$cantidad];
		
		$promediototal = $tiempototal/$turnostotal;
		echo "intervalo estadistico: ".$fila1['intervalo']."<br>";
		echo " intervalo real:".$promediototal."<br>";	
		echo "porcentaje: ".($promediototal/$fila1['intervalo']);
?>
