<?php
$muni = 1;
$muni = $_POST['muni'];

$celular = $_POST['celular'];
//$celular = "52097750";
$tiempo = "15";
$t_num = $_POST['num'];
//$t_num = "80";
$t_abc = $_POST['abc'];
$t_abc = "A";


	$dbc = @mysqli_connect('localhost', 'armatuli_rc', 'rc2014rc', 'armatuli_rc');
   
	@mysqli_select_db($dbc, "armatuli_rc");
	
	if(isset($celular)){
		$consulta = "INSERT INTO clientes (`id`, `telefono`, `min_pre`, `turno_num`, `turno_abc`, `id_muni`) VALUES (NULL, '$celular', '$tiempo', '$t_num', '$t_abc', '$muni')";
		$resultado = Mysqli_query($dbc, $consulta);
		

		$consulta1 = "SELECT * FROM clientes where telefono = $celular order by id desc";
		$resultado1 = Mysqli_query($dbc, $consulta1);
		$fila = mysqli_fetch_assoc($resultado1);
		echo $fila['telefono']." ".$fila['turno_num'];
		
	}
?>
