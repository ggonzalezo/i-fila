<?php
	$dbc = @mysqli_connect('localhost', 'armatuli_rc', 'rc2014rc', 'armatuli_rc');
	@mysqli_select_db($dbc, "armatuli_rc");
	
	
		$consulta = "SELECT * FROM municipalidades";
		$resultado = Mysqli_query($dbc, $consulta);
		while ($fila = mysqli_fetch_assoc($resultado)){
			echo $fila['id']."_".$fila['comuna']."_".$fila['lat']."_".$fila['lon']."<br>";
		}
?>

