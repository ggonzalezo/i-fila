 <?php
    $host_db = "localhost"; // Host de la BD
    $usuario_db = "unsteala_admin"; // Usuario de la BD
    $clave_db = "9202-PdQ"; // Contraseña de la BD
    $nombre_db = "unsteala_sq"; // Nombre de la BD
    
    //conectamos y seleccionamos db
    mysql_connect($host_db, $usuario_db, $clave_db);
    mysql_select_db($nombre_db);
?> 