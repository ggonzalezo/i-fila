<?php
$nombre = $_POST['nombre'];
$tipo = $_POST['tipo'];
$lat = $_POST['lat'];
$long = $_POST['long'];
$pais = $_POST['pais'];
$direccion = $_POST['direccion'];
$horario_apertura_am = $_POST['horario_apertura_am'];
$horario_cierre_am= $_POST['horario_cierre_am'];
$horario_apertura_pm = $_POST['horario_apertura_pm'];
$horario_cierre_pm = $_POST['horario_cierre_pm'];

echo $nombre." ".$tipo." ".$lat." ".$long." ".$pais." ".$direccion." ".$horario_apertura_am." ".$horario_cierre_am." ".$horario_apertura_pm." ".$horario_cierre_pm;
?>