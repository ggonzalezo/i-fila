<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css" />
<LINK href="hojacss-cliente.css" rel="stylesheet" type="text/css">
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
</head>

<script>

	$(document).ready(function(){
		
		//detectar pais
		$.getJSON('http://api.wipmania.com/jsonp?callback=?', function (data) {
					//alert('País: ' + data.address.country);
					$("#pais").val(data.address.country);
				});//fin detecion pais
			
				
	$('#ingresar').click(function() {
			
			var nombre = $("#nombre").val();
			var tipo = $("#tipo").val();
			var lat = $("#lat").val();
			var long = $("#long").val();
			var direccion = $("#direccion").val();
			var pais = $("#pais").val();
			var horario_apertura_am = $("#horario_apertura_am").val();
			var horario_cierre_am = $("#horario_cierre_am").val();
			var horario_apertura_pm = $("#horario_apertura_pm").val();
			var horario_cierre_pm = $("#horario_cierre_pm").val();
			
			$.post( "new_local_save.php",{nombre: nombre, tipo: tipo,lat: lat,long: long, pais: pais,direccion: direccion, horario_apertura_am: horario_apertura_am, horario_apertura_pm: horario_apertura_pm,horario_cierre_am: horario_cierre_am,horario_cierre_pm: horario_cierre_pm},function(respuesta){				
						alert(respuesta);
					
				});
		
		});
		
		
		//función geolocalizacion
		$('#geo').click(function(){
			if (navigator.geolocation) {
				navigator.geolocation.watchPosition(showPosition);
			} else { 
				alert("Geolocation is not supported by this browser.");}
			});	
		function showPosition(position) {
			$("#lat").val(position.coords.latitude);
			$("#long").val(position.coords.longitude);	
		}//fin geolocalizacion
	

		
	});	
</script>

<body>
<div data-role="page">
	<div data-role="header">
    <h1>SmartQ load new local</h1>
    </div>
    
    
    <div data-role="content" data-theme="c">
    	<div data-role="content">
        </div>

    Nombre: <input data-mini="true" type="text" id="nombre"/> 
    
    <select id="tipo">
    	<option value="1">Municipalidad</option>
        <option value="2">Banco</option>
        <option value="3">Hospital</option>
        <option value="4">Otro</option>
    </select>  
    Ubicación:
    <div class="ui-grid-a">
    <div class="ui-block-a">
     <input data-mini="true" type="text" id="lat" placeholder="lat"/>  
     </div>
   <div class="ui-block-b">
     <input data-mini="true" type="text" id="long" placeholder="long"/> 
     </div> 
	</div>
     <div class="ui-grid-a">
    <div class="ui-block-a">
      <button data-mini="true" data-role="button"  id="geo">Get location</button>
     </div>
   <div class="ui-block-b">
     <input data-mini="true" type="text" id="pais" placeholder="pais"/> 
     </div> 
	</div>
    
      <input data-mini="true" type="text" id="direccion" placeholder="direcci&oacute;n"/>  
      horarios de atenci&oacute;n:
      <div class="ui-grid-a">
      		<div class="ui-block-a"><p class="center">
            <input data-mini="true" type="tel" id="horario_apertura_am"/ placeholder="AM desde">
            </div>
      		<div class="ui-block-b"><p class="center">
            <input data-mini="true" type="tel" id="horario_cierre_am"/ placeholder="AM hasta">
            </div>
            <div class="ui-block-a"><p class="center">
            <input data-mini="true" type="tel" id="horario_apertura_pm"/ placeholder="PM desde">
            </div>
      		<div class="ui-block-b"><p class="center">
            <input data-mini="true" type="tel" id="horario_cierre_pm"/ placeholder="PM hasta">
            </div>
    	</div>
        
     <fieldset data-role="controlgroup" data-type="horizontal">
        <legend>Dias de la semana:</legend>
        <input data-mini="true" type="checkbox" name="checkbox-h-2a" id="checkbox-h-2a">
        <label for="checkbox-h-2a">L</label>
        <input data-mini="true" type="checkbox" name="checkbox-h-2b" id="checkbox-h-2b">
        <label for="checkbox-h-2b">M</label>
        <input data-mini="true" type="checkbox" name="checkbox-h-2c" id="checkbox-h-2c">
        <label for="checkbox-h-2c">W</label>
        <input data-mini="true" type="checkbox" name="checkbox-h-2d" id="checkbox-h-2d">
        <label for="checkbox-h-2d">J</label>
        <input data-mini="true" type="checkbox" name="checkbox-h-2e" id="checkbox-h-2e">
        <label for="checkbox-h-2e">V</label>
        <input data-mini="true" type="checkbox" name="checkbox-h-2f" id="checkbox-h-2f">
        <label for="checkbox-h-2f">S</label>
        <input data-mini="true" type="checkbox" name="checkbox-h-2g" id="checkbox-h-2g">
        <label for="checkbox-h-2g">D</label>
    </fieldset>
        
      <br />
     	<button data-role="button"  id="ingresar">Ingresar</button>
        <p align="center"><span id="error" style="color:red"></span><span id="info"></span></p>
    </div>
</div>
</body>
</html>


