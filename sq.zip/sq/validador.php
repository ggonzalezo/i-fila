<?php
session_start();
include("acceso_db.php");
$letra = $_GET["letra"];	
$numero = $_GET["numero"];
if(isset($_SESSION['id_cliente'])){
	$id =$_SESSION['id_cliente'];
	$sql_cliente = mysql_query("SELECT * FROM clientes where id = $id order by id desc LIMIT 1");
	$row_cliente = mysql_fetch_array($sql_cliente);
		$entradas = $row_clientes['entradas'];
		$entradas = $entradas+1;
	$sql = mysql_query("UPDATE `clientes` SET `letra`= '".$letra."',`numero`= '".$numero."',`entradas`= '".$entradas."' WHERE id = '".$id."'");
    $row = mysql_fetch_array($sql);
}else{
	$sql = mysql_query("INSERT INTO `clientes`(`letra`, `numero`) VALUES ('$letra','$numero')");
    $row = mysql_fetch_array($sql);
	$sql_cliente = mysql_query("SELECT * FROM clientes order by id desc LIMIT 1");
	$row_cliente = mysql_fetch_array($sql_cliente);
	$id =$row_cliente['id'];	
	$_SESSION['id_cliente'] = $id;
}
	echo $id."_".$numero;
?>