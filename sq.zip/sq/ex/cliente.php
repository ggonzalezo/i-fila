<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css" />
<LINK href="hojacss-cliente.css" rel="stylesheet" type="text/css">
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
</head>
<script>

	$(document).ready(function(){

	var minumero = '<?php echo $_GET['num'];?>';
	var muni = '<?php echo $_GET['muni'];?>';
	var primera = 0;
	
	$( "#num_cliente" ).text(minumero +"_"+muni);
	
	//$( "#header" ).text("su turno: " + minumero);
	
		function actualizar(){
			
			$.get( "../intervalo.php",{id_muni: muni},function(respuesta){
			//se obtine intervalo, numero real , hora_real
		var split = respuesta.split(" ");		
		var intervalo = split['0']; 
		var num_real = split['1'];
		var hora_real = split['3'];
			var split_hora = hora_real.split(":");
			var hora_en_minutos = ((split_hora['0']*60)+split_hora['1']*1);
		
		// se calcula timepo y numero desde hora de apertura registro civil
		var d_est = new Date();
		var mactuales_est = d_est.getMinutes();
		var hactuales_est = d_est.getHours();
		var sactuales_est = d_est.getSeconds();
		var hinicio = 9;
		var mdia = (hactuales_est)*60 +mactuales_est + sactuales_est/60;	
		var mtrans = mdia-hinicio*60;
		var numestimado = Math.floor(mtrans/intervalo);
		
		var desfase_real_estimado = mdia - hora_en_minutos ;
		var num_estimado_act = num_real*1 + Math.floor(desfase_real_estimado/intervalo);
		
		
		// se compara información
	
		num_act = num_estimado_act*1;
	
	
	//se calcula numero faltantes
	var turnosfaltantes =  minumero - num_act;
	
	//tiempo estimado
	var tiempoestimado = Math.floor(intervalo* 0.9 * turnosfaltantes);
	var htiempoestimado = Math.floor(tiempoestimado/60);
	var mtiempoestimado = tiempoestimado - htiempoestimado*60;
	if(htiempoestimado>0){
	var hmtiempoestimado =  htiempoestimado + "h " + mtiempoestimado + "m";
	}else{
	var hmtiempoestimado =   mtiempoestimado + "m";
	}
	//hora estimada
				var d = new Date();
				var v = new Date();
					v.setMinutes(d.getMinutes() + tiempoestimado);
				var hestimado = v.getHours();
				var mestimado = v.getMinutes();
				  if (mestimado < 10)
					  mestimado = "0" + mestimado;
				//alert(v);
				var horaestimada = hestimado +":" + mestimado;
				
	if(tiempoestimado >= 0){
	$( "#tiempo_estimado" ).text(hmtiempoestimado);
	$( "#numero_actual" ).text( num_act);
	$( "#hora_estimada" ).text( horaestimada);
	}
	
	if(tiempoestimado < 0){
	$( "#tiempo_estimado" ).text(":(");
	$( "#numero_actual" ).text( num_act);
	$( "#hora_estimada" ).text( ":(");
	}
	
	//se cargan datos en página de modificacion
						$( "#aumentar3" ).text(num_act+3);
						$( "#aumentar2" ).text(num_act+2);
						$( "#aumentar1" ).text(num_act+1);
						$( "#aumentar0" ).text(num_act);
						$( "#aumentar-1" ).text(num_act-1);
						$( "#aumentar-2" ).text(num_act-2);
						$( "#aumentar-3" ).text(num_act-3);	
						
						
						$( "#num_actual_verificador" ).text(num_act);
						// verificar numero actual	
					if (primera == 0){		
					$.mobile.changePage( "#verificar_num", {  
							transition: "flip"
							} );
						primera = 1;	
					}				
		});
		
		
		//funciones
		}
		actualizar();
		setInterval(function(){
			actualizar()},4000
			);
			
		$('#exit').click(function() {
			window.location = "index.html";
		});
		
		$('#modificar').click(function() {
			$.mobile.changePage( "#num_real", {  
			transition: "flip"
			} );
		});
		
		$('#actualizar').click(function() {
			$( "#tiempo_estimado" ).text("-");
			$( "#turnosfaltantes" ).text("-");
			$( "#numero_actual" ).text( "-");
			$( "#hora_estimada" ).text( "-");
			actualizar();
		});
		
		$('#no').click(function() {
			$.mobile.changePage( "#num_real", {  
			transition: "flip"
			} );
		});
		
		$('#si').click(function() {
			$.mobile.changePage( "#principal", {  
			transition: "flip"
			} );
		});
		
		$('#no_lo').click(function() {
			$.mobile.changePage( "#principal", {  
			transition: "flip"
			} );
		});
		
		

	// se selecciona numero real
	$('.button').click(function() {
			var numero = $(this).html();
			$.post( "../modificar_numero.php",{numero: numero, muni: muni },function(respuesta){
				actualizar();
				$.mobile.changePage( "#principal",{
				transition: "flip"	
				});
				
			});
        });	
	//	
	//se corrobora numero actual
		$('#si').click(function() {
			var numero = $('#num_actual_verificador').html();
			$.post( "../modificar_numero.php",{numero: numero, muni: muni },function(respuesta){
				actualizar();			
			});
        });	
		
		
	});
	
</script>
<body>
<div data-role="page" id="principal">
	<div data-role="header">
    <a class="ui-btn ui-icon-home ui-btn-icon-notext ui-corner-all" id="exit">exit</a>
    <h1 id="header">SmartQ</h1>
    <a class="ui-btn ui-icon-home ui-corner-all" id="num_cliente">-</a>
    </div> 
    
   <div data-role="content" data-theme="c">
  
 		<p class="center">
         Tiempo estimado<br />
        <span  id="tiempo_estimado">-</span><br />
        </p>
    	<div class="ui-grid-a">
      		<div class="ui-block-a"><p class="center">
                <span>N&uacute;mero actual</span><br />
                <span id="numero_actual" class="info">-</span>
                <br /><span id="modificar">Modificar</span>
            </p></div>
      		<div class="ui-block-b"><p class="center">
                <span>Hora estimada</span><br />
                <span id="hora_estimada" class="info">-</span>
                <br /><span id="actualizar">Actualizar</span>
            </p></div>
    	</div>
        <br />
        <a href="#descuentos" data-role="button" data-transition="flip">descuentos</a>
	</div>

</div>


<div data-role="page" id="num_real">
  <div data-role="header">
  	<a href="#principal" data-transition="flip" data-icon="back">volver</a>
    <h2>modificar</h2>
  </div>
  <div role="main" class="ui-content">
    		<button data-role="button" id="aumentar3" class="button" data-mini="true">-</button>
			<button data-role="button"  id="aumentar2" class="button" data-mini="true">-</button>
			<button data-role="button"  id="aumentar1" class="button" data-mini="true">-</button>
			<button data-role="button"  id="aumentar0" class="button" data-mini="true">-</button>
			<button data-role="button"  id="aumentar-1" class="button" data-mini="true">-</button>
			<button data-role="button"  id="aumentar-2" class="button" data-mini="true">-</button>
			<button data-role="button"  id="aumentar-3" class="button" data-mini="true">-</button>
  </div>
</div>


<div data-role="page" id="verificar_num">
  <div data-role="header">
  	<a href="#principal" data-transition="flip" data-icon="back">volver</a>
    <h2></h2>
  </div>
  <div role="main" class="ui-content">
		<p class="center" >Es correcto el siguiente n&uacute;mero?<br />
        <span  id="num_actual_verificador" class="center">-</span></p>
        <button data-role="button" id="si" >Si</button>
        <button data-role="button" id="no" >No</button>
        <button data-role="button" id="no_lo" >No lo estoy viendo</button>
  </div>
</div>

<div data-role="page" id="descuentos">
  <div data-role="header">
  <a href="#principal" data-transition="flip" data-icon="back">volver</a>
    <h2>descuentos</h2>
  </div>
  <div role="main" class="ui-content">
		<p id"texto_descuentos">Pr&oacute;ximamente encontrar&aacute;s los mejores descuentos en locales cercanos</p>
        <p>Si quieres aparecer aqu&iacute; cont&aacute;ctanos</p>
        <p>cristobalcabello92@gmail.com</p>
  </div>
</div>

</body>
</html>
