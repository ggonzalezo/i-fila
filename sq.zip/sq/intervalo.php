<?php
// se carga información de  intervalo estadistico y numero real (actualizado por el usaurio)
$id_muni = $_GET["id_muni"];

		include("acceso_db.php");
	
		$sql_local = mysql_query("SELECT * FROM local where id =  $id_muni order by id asc LIMIT 1");
		$row_local = mysql_fetch_array($sql_local);
		
		$limit = 12; //cantidad de datos a ser evaluados
		
		$turno = array();
		$segundos = array();
		$intervalo = array();
		$sql_turnos = mysql_query("SELECT * FROM turnos where id_local =  $id_muni order by id desc LIMIT $limit");
		while($row_turnos = mysql_fetch_array($sql_turnos)){
			$turno[] = $row_turnos['turno'] ;
			$segundos[] = $row_turnos['segundos'];
			$intervalo[] = $row_turnos['intervalo']*1;
		}
		$intervalo_total = 0;
		for ($i = 0; $i <= $limit-1; $i++) {
			if(isset($intervalo[$i])){
			$intervalo_total = $intervalo_total + $intervalo[$i];
			}else{
			$intervalo_total = $intervalo_total + $row_local['intervalo'];	
			}
		}
		
		$intervalo_prom = round($intervalo_total/$limit);//se dividie para estabilizarlo en numeros de a 10
		$intervalo_prom = $intervalo_prom;
		
		// para pruebas:
		//$intervalo_prom = $row_local['intervalo'];
		//$intervalo_prom = 70+10;
		//$turno[0] = 100;
		//$segundos[0] = 1459171617 ;
		//echo $turno[0]." ".$turno[1]." ".$turno[2]."<br>";
		
		echo "_".$intervalo_prom."_".$turno[0]."_".$segundos[0]."_".time();	
?>